def handler(event, context):
    print("S3 event received!")
    print(event)
